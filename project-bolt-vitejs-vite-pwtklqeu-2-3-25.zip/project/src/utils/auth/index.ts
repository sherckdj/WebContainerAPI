export { signIn, handleAuthError } from './auth-service';
export type { AuthenticatedUser, AuthResult } from './types';